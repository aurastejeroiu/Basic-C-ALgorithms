#include <iostream>
#include <string.h>

using namespace std;

int main()
{ char sir[]={"CioBan"};
  int i=0;
  while (i<strlen(sir))
    {if(islower(sir[i])) cout<< sir[i];
      i++;
    }
  cout<<endl;
  i=0;
  while (i<strlen(sir))
    {if(isupper(sir[i])) cout<< sir[i];
      i++;
    }

  return 0;
}
