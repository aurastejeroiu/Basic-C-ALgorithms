#include <iostream>

using namespace std;
//P1.1a In cate zerouri se termina produsul numerelor x[1]*...*x[n], fara a calcula efectiv
        produsul.

//Idee: Un zero final este dat de 2*5, deci tre' calculat min{2^Exp2,5^Exp5}
//      adica de cate ori toti factorii se divid cu 2 si 5.

int main()
{   long x[100];
    int i,n;
    int NrEx2,NrEx5;
    cout <<"da numarul de factori";
    cin  >>n;
    for (i=1;i<=n;i++)
      { cout<<"x["<<i<<"]=";
        cin >> x[i];
      }
    NrEx2=0;
    NrEx5=0;
    for(i=1;i<=n;i++)
       { long aux=x[i];
         while (aux % 2==0) {
                NrEx2++;
                aux/=2;
               }
         aux=x[i];
         while (aux % 5==0) {
                NrEx5++;
                aux/=5;
                }
       }
    if(NrEx2<NrEx5) cout<<" produsul se termina in "<<NrEx2<< " zerouri";
    else            cout<<" produsul se termina in "<<NrEx5<< " zerouri";
    cout << "Hello world!" << endl;
    return 0;
}
