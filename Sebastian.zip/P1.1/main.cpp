#include <iostream>

using namespace std;

//1.1. Fie i,j,k numere naturale. Sa se determine restul impartirii
//     numarului (i^j) la k; deci (i^j)mod k.
//     Idee:
//          - se calculeaza la fiecare pas de inmultire restul;
//          - practic se inmultesc resturile modulo k.
int main()
{   long i,j,k,Rest;
    cout<<"da i:"; cin >>i;
    cout<<"da j:"; cin >>j;
    cout<<"da k:"; cin >>k;
    Rest=i%k;
    for(long l=2; l<=j; l++)
        Rest=(Rest*(i%k))%k;
    cout<<Rest;
    return 1;
}
