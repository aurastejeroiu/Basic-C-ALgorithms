#include <iostream>

using namespace std;

int main()
{   int j,S,n;
    cout << "da n:";
    cin  >> n;

    for(int i=1;i<=n/2;i++)
    { S=i;
      j=i;
      while(S<n)
      { j++;
        S+=j;
      }
      if(S==n)
      {
          for(int k=i;k<=j;k++)
            cout<<k<<",";
          cout<<endl;
      }
    }


    return 0;
}
