#include <iostream>

using namespace std;
void Spirala(int n, int a[10][10])
{
    int i,i2,j,j2, h=0;
    while(h<=n*n)
    {
        i=1;
        for(int k=i;k<=n-1;k++)
            a[i][k]=++h;
        j=n;
        for(int k=n-j+1;k<=j-1;k++)
            a[k][j]=++h;
        i2=n;
        for( int k=i2;k>n-i2+1;k--)
            a[i2][k]=++h;
        j2=1;
        for(int k=n-j2+1;k>j2;k--)
            a[k][j2]=++h;
        i++;
        j--;
        i2--;
        j2++;
        if(n*n-h==1) a[n/2+1][n/2+1]=++h;
    }
}
int main()
{
    int n,a[10][10];
    cout<<"da n: ";
    cin>>n;
    Spirala(n,a);
    for(int i=1;i<=n;i++)
        {
            for(int j=1;j<=n;j++)
                cout<<a[i][j]<<" ";
            cout<<endl;
        }
    cout << "Hello world!" << endl;
    return 0;
}
