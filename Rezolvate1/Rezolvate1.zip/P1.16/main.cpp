#include <iostream>
#include <cstring>
using namespace std;


int main()
{   int n,y,z;
    string sapt[]={"duminica","luni","marti","miercuri","joi","vineri","sambata"};
    cout<<"da ziua da 1 ianuarie:";
    cin >>z;
    cout<<"da numar de zile:";
    cin >>n;
    cout<<endl<<n<<endl;
    y=(z+n-1)%7;
    
    cout<<y<<endl;
    cout<<sapt[y];
    return 0;
}
