#include <iostream>

using namespace std;

int Ordinal(int z, int l, int a){
    int luni[]={0,31,28,31,30,31,30,31,31,30,31,30,31};
    if(a%4==0) luni[2]=29;
    int Ord=z;
    for(int i=1;i<l;i++)
        Ord+=luni[i];
    return Ord;
}
int main()
{   int nz,nl,na,cz,cl,ca;
    long Zile=0;
    cout<<"da ziua nast:";cin>>nz;
    cout<<"da luna nast:";cin>>nl;
    cout<<"da anul nast:";cin>>na;

    cout<<"da ziua c:";cin>>cz;
    cout<<"da luna c:";cin>>cl;
    cout<<"da anul c:";cin>>ca;

    if(na==ca)  cout<<Ordinal(cz,cl,ca)-Ordinal(nz,nl,na); ///daca anii coincid
    else {                                                 ///ani diferiti
           if(na%4==0) Zile=366-Ordinal(nz,nl,na);     ///adaugare nr de zile din anul nasterii
           else        Zile=365-Ordinal(nz,nl,na);

          for(int i=na+1;i<=ca-1;i++)                 ///adunare pentru anii intregi
           {   Zile+=365;
               if(i%4==0) Zile++;
          }
          Zile+=Ordinal(cz,cl,ca);                    ///adaugare nr de zile din anul curent
          cout<<endl<<Zile<<" zile"<<endl;
    }
    cout<<endl<< "Program terminat" << endl;
    return 0;
}
